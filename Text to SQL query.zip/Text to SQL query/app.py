import streamlit as st
import sqlite3
import google.generativeai as genai

Google_Api_key = "AIzaSyC7_OnJ7A8DRB6uPVwLLBjc9r6bwm5ymoU"
genai.configure(api_key=Google_Api_key)
model = genai.GenerativeModel('gemini-pro')

def sql_query(sql):
    conn = sqlite3.connect("student.db")
    curr = conn.cursor()
    curr.execute(sql)
    rows = curr.fetchall()
    conn.commit()
    conn.close()
    for row in rows:
        st.write(row)

def main():
    st.set_page_config(page_title="SQL Query Generator", page_icon=":robot:")
    st.markdown(
        """
            <div style="text-align:center;">
                <h1>SQL Query Generator</h1>
            </div>
        """,
        unsafe_allow_html=True
    )
    
    text_input = st.text_area("Enter your Query")
    submit = st.button("Generate")
    
    if submit:
        with st.spinner("Generating SQL query..."):
            template = """
            Create a SQL query using the following Text:
            {text_input}
            I only want the SQL query without any explanation or Markdown formatting and without showing sql heading.
            """
            formatted_template = template.format(text_input=text_input)
            response = model.generate_content(formatted_template)
            sql_query_str = response.text.strip()

            # Remove any unexpected characters or formatting
            sql_query_str = sql_query_str.replace('```', '').strip()

            st.write("Generated SQL Query:")
            st.code(sql_query_str)
            try:
                sql_query(sql_query_str)
            except sqlite3.OperationalError as e:
                st.error(f"SQL error: {e}")

if __name__ == "__main__":
    main()
