import sqlite3

connection = sqlite3.connect("student.db")
cursor = connection.cursor()

# Corrected create table statement
cursor.execute("CREATE TABLE Students (Name VARCHAR(255), Age INT, Class VARCHAR(255))")

# Insert statements
cursor.execute("INSERT INTO Students VALUES ('Waleed', 18, '10th')")
cursor.execute("INSERT INTO Students VALUES ('Hassan', 19, '9th')")
cursor.execute("INSERT INTO Students VALUES ('Basim', 20, '8th')")

# Commit the changes and close the connection
connection.commit()
connection.close()
